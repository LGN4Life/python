---
files:
  - https://projects.fivethirtyeight.com/polls-page/president_primary_polls.csv
  - https://projects.fivethirtyeight.com/polls-page/president_polls.csv
  - https://projects.fivethirtyeight.com/polls-page/senate_polls.csv
  - https://projects.fivethirtyeight.com/polls-page/house_polls.csv
  - https://projects.fivethirtyeight.com/polls-page/governor_polls.csv
  - https://projects.fivethirtyeight.com/polls-page/president_approval_polls.csv
  - https://projects.fivethirtyeight.com/polls-page/generic_ballot_polls.csv
---

# Polls

This file contains links to the data behind [Latest Polls](https://projects.fivethirtyeight.com/polls/).

- [Presidential Primary Polls](https://projects.fivethirtyeight.com/polls-page/president_primary_polls.csv)
- [Presidential General Election Polls](https://projects.fivethirtyeight.com/polls-page/president_polls.csv)
- [Senate Polls](https://projects.fivethirtyeight.com/polls-page/senate_polls.csv)
- [House Polls](https://projects.fivethirtyeight.com/polls-page/house_polls.csv)
- [Governor Polls](https://projects.fivethirtyeight.com/polls-page/governor_polls.csv)
- [Presidential Approval Polls](https://projects.fivethirtyeight.com/polls-page/president_approval_polls.csv)
- [Generic Ballot Polls](https://projects.fivethirtyeight.com/polls-page/generic_ballot_polls.csv)


